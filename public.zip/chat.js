// Esperar a que el DOM cargue
document.addEventListener("DOMContentLoaded", function () {
    iniciarApp();
});

// Función principal para iniciar la app
function iniciarApp() {
    if (!localStorage.getItem("usuario")) {
        mostrarPantallaRegistro();
    } else {
        iniciarSesion();
    }
}

// Mostrar pantalla de registro
function mostrarPantallaRegistro() {
    let nombreUsuario = prompt("Ingresa tu nombre de usuario:");
    
    if (nombreUsuario && nombreUsuario.trim() !== "") {
        let userId = generarIdUsuario();
        let usuario = {
            nombre: nombreUsuario,
            id: userId
        };
        
        localStorage.setItem("usuario", JSON.stringify(usuario));
        alert(`¡Registro exitoso! Tu ID es: ${userId}`);
        iniciarSesion();
    } else {
        alert("Debes ingresar un nombre válido.");
        mostrarPantallaRegistro();
    }
}

// Generar un ID único con el formato 10-XXXXXXXXXX
function generarIdUsuario() {
    let numeros = "";
    for (let i = 0; i < 10; i++) {
        numeros += Math.floor(Math.random() * 10);
    }
    return `10-${numeros}`;
}

// Iniciar sesión si ya existe un usuario registrado
function iniciarSesion() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    if (usuario) {
        console.log(`Bienvenido ${usuario.nombre} (ID: ${usuario.id})`);
        cargarInterfazChat();
    }
}

// Cargar la interfaz del chat después del registro
function cargarInterfazChat() {
    document.body.innerHTML = `
        <div id="chatContainer">
            <h2>Bienvenido, ${JSON.parse(localStorage.getItem("usuario")).nombre}</h2>
            <div id="chatMensajes"></div>
            <input type="text" id="inputMensaje" placeholder="Escribe un mensaje...">
            <button id="btnEnviar">Enviar</button>
        </div>
    `;

    // Agregar eventos después de cargar la interfaz
    document.getElementById("btnEnviar").addEventListener("click", enviarMensaje);
}

// Función para enviar un mensaje
function enviarMensaje() {
    let input = document.getElementById("inputMensaje");
    let mensaje = input.value.trim();

    if (mensaje !== "") {
        let chatMensajes = document.getElementById("chatMensajes");
        let nuevoMensaje = document.createElement("div");
        nuevoMensaje.classList.add("mensaje-usuario");
        nuevoMensaje.textContent = mensaje;
        chatMensajes.appendChild(nuevoMensaje);
        input.value = "";
    }
}
// Función para agregar un contacto a la lista
function agregarContacto() {
    let nuevoId = prompt("Ingresa el ID del usuario que quieres agregar:");
    
    if (nuevoId && nuevoId.match(/^10-\d{10}$/)) {
        let contactos = JSON.parse(localStorage.getItem("contactos")) || [];
        
        if (!contactos.includes(nuevoId)) {
            contactos.push(nuevoId);
            localStorage.setItem("contactos", JSON.stringify(contactos));
            alert("¡Contacto agregado exitosamente!");
        } else {
            alert("Este contacto ya está en tu lista.");
        }
    } else {
        alert("El ID ingresado no es válido. Debe seguir el formato 10-XXXXXXXXXX.");
    }
}

// Función para mostrar los contactos guardados
function mostrarContactos() {
    let contactos = JSON.parse(localStorage.getItem("contactos")) || [];
    
    if (contactos.length === 0) {
        alert("No tienes contactos guardados.");
    } else {
        let lista = "Tus contactos:\n";
        contactos.forEach((id, index) => {
            lista += `${index + 1}. ID: ${id}\n`;
        });
        alert(lista);
    }
}

// Función para cargar el menú de contactos en la interfaz
function cargarMenuContactos() {
    let chatContainer = document.getElementById("chatContainer");

    let contactosMenu = document.createElement("div");
    contactosMenu.id = "contactosMenu";
    contactosMenu.innerHTML = `
        <button id="btnAgregarContacto">Agregar Contacto</button>
        <button id="btnVerContactos">Ver Contactos</button>
    `;

    chatContainer.prepend(contactosMenu);

    document.getElementById("btnAgregarContacto").addEventListener("click", agregarContacto);
    document.getElementById("btnVerContactos").addEventListener("click", mostrarContactos);
}

// Modificar la función cargarInterfazChat para incluir el menú de contactos
function cargarInterfazChat() {
    document.body.innerHTML = `
        <div id="chatContainer">
            <h2>Bienvenido, ${JSON.parse(localStorage.getItem("usuario")).nombre}</h2>
            <div id="chatMensajes"></div>
            <input type="text" id="inputMensaje" placeholder="Escribe un mensaje...">
            <button id="btnEnviar">Enviar</button>
        </div>
    `;

    cargarMenuContactos();

    // Agregar eventos después de cargar la interfaz
    document.getElementById("btnEnviar").addEventListener("click", enviarMensaje);
}
// Función para enviar un mensaje privado a un contacto específico
function enviarMensajePrivado() {
    let contactos = JSON.parse(localStorage.getItem("contactos")) || [];
    
    if (contactos.length === 0) {
        alert("No tienes contactos guardados. Agrega un contacto primero.");
        return;
    }

    let destinatario = prompt("Ingresa el ID del usuario al que quieres enviar un mensaje:");

    if (contactos.includes(destinatario)) {
        let mensaje = prompt("Escribe tu mensaje:");

        if (mensaje && mensaje.trim() !== "") {
            let usuario = JSON.parse(localStorage.getItem("usuario"));
            let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

            if (!mensajes[destinatario]) {
                mensajes[destinatario] = [];
            }

            mensajes[destinatario].push({
                de: usuario.id,
                contenido: mensaje,
                timestamp: new Date().toLocaleString()
            });

            localStorage.setItem("mensajes", JSON.stringify(mensajes));
            alert("Mensaje enviado con éxito.");
        } else {
            alert("No puedes enviar un mensaje vacío.");
        }
    } else {
        alert("El ID ingresado no está en tu lista de contactos.");
    }
}

// Función para recibir mensajes privados
function recibirMensajes() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    if (mensajes[usuario.id] && mensajes[usuario.id].length > 0) {
        let bandeja = "Mensajes recibidos:\n";
        
        mensajes[usuario.id].forEach((mensaje, index) => {
            bandeja += `${index + 1}. De ${mensaje.de}: ${mensaje.contenido} (${mensaje.timestamp})\n`;
        });

        alert(bandeja);
        
        // Limpiar mensajes después de leerlos
        delete mensajes[usuario.id];
        localStorage.setItem("mensajes", JSON.stringify(mensajes));
    } else {
        alert("No tienes mensajes nuevos.");
    }
}

// Modificar la interfaz para incluir opciones de mensajes privados
function cargarInterfazChat() {
    document.body.innerHTML = `
        <div id="chatContainer">
            <h2>Bienvenido, ${JSON.parse(localStorage.getItem("usuario")).nombre}</h2>
            <div id="chatMensajes"></div>
            <input type="text" id="inputMensaje" placeholder="Escribe un mensaje...">
            <button id="btnEnviar">Enviar</button>
            <button id="btnMensajePrivado">Mensaje Privado</button>
            <button id="btnRecibirMensajes">Ver Mensajes Recibidos</button>
        </div>
    `;

    cargarMenuContactos();

    document.getElementById("btnEnviar").addEventListener("click", enviarMensaje);
    document.getElementById("btnMensajePrivado").addEventListener("click", enviarMensajePrivado);
    document.getElementById("btnRecibirMensajes").addEventListener("click", recibirMensajes);
}

// Función para mostrar un efecto visual cuando llega un mensaje
function efectoNotificacion() {
    let chatContainer = document.getElementById("chatContainer");

    if (chatContainer) {
        chatContainer.classList.add("nueva-notificacion");
        setTimeout(() => {
            chatContainer.classList.remove("nueva-notificacion");
        }, 1000);
    }
}

// Detectar si hay mensajes nuevos cada 5 segundos
setInterval(() => {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    if (mensajes[usuario.id] && mensajes[usuario.id].length > 0) {
        efectoNotificacion();
    }
}, 5000);
// Función para encriptar un mensaje usando una clave simple (Cifrado César)
function encriptarMensaje(mensaje, clave) {
    let resultado = "";
    for (let i = 0; i < mensaje.length; i++) {
        let charCode = mensaje.charCodeAt(i);
        resultado += String.fromCharCode(charCode + clave);
    }
    return resultado;
}

// Función para desencriptar un mensaje
function desencriptarMensaje(mensaje, clave) {
    let resultado = "";
    for (let i = 0; i < mensaje.length; i++) {
        let charCode = mensaje.charCodeAt(i);
        resultado += String.fromCharCode(charCode - clave);
    }
    return resultado;
}

// Función para enviar un mensaje encriptado
function enviarMensajePrivadoSeguro() {
    let contactos = JSON.parse(localStorage.getItem("contactos")) || [];
    
    if (contactos.length === 0) {
        alert("No tienes contactos guardados. Agrega un contacto primero.");
        return;
    }

    let destinatario = prompt("Ingresa el ID del usuario al que quieres enviar un mensaje:");

    if (contactos.includes(destinatario)) {
        let mensaje = prompt("Escribe tu mensaje:");

        if (mensaje && mensaje.trim() !== "") {
            let usuario = JSON.parse(localStorage.getItem("usuario"));
            let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};
            let clave = 5; // Clave de encriptación simple

            let mensajeEncriptado = encriptarMensaje(mensaje, clave);

            if (!mensajes[destinatario]) {
                mensajes[destinatario] = [];
            }

            mensajes[destinatario].push({
                de: usuario.id,
                contenido: mensajeEncriptado,
                timestamp: new Date().toLocaleString()
            });

            localStorage.setItem("mensajes", JSON.stringify(mensajes));
            alert("Mensaje encriptado y enviado con éxito.");
        } else {
            alert("No puedes enviar un mensaje vacío.");
        }
    } else {
        alert("El ID ingresado no está en tu lista de contactos.");
    }
}

// Función para recibir mensajes desencriptados
function recibirMensajesSeguro() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};
    let clave = 5; // Clave de desencriptación

    if (mensajes[usuario.id] && mensajes[usuario.id].length > 0) {
        let bandeja = "Mensajes recibidos:\n";
        
        mensajes[usuario.id].forEach((mensaje, index) => {
            let mensajeDesencriptado = desencriptarMensaje(mensaje.contenido, clave);
            bandeja += `${index + 1}. De ${mensaje.de}: ${mensajeDesencriptado} (${mensaje.timestamp})\n`;
        });

        alert(bandeja);
        
        // Limpiar mensajes después de leerlos
        delete mensajes[usuario.id];
        localStorage.setItem("mensajes", JSON.stringify(mensajes));
    } else {
        alert("No tienes mensajes nuevos.");
    }
}

// Modificar la interfaz para incluir mensajes seguros
function cargarInterfazChatSeguro() {
    document.body.innerHTML = `
        <div id="chatContainer">
            <h2>Bienvenido, ${JSON.parse(localStorage.getItem("usuario")).nombre}</h2>
            <div id="chatMensajes"></div>
            <input type="text" id="inputMensaje" placeholder="Escribe un mensaje...">
            <button id="btnEnviar">Enviar</button>
            <button id="btnMensajePrivadoSeguro">Mensaje Seguro</button>
            <button id="btnRecibirMensajesSeguro">Ver Mensajes Seguros</button>
        </div>
    `;

    cargarMenuContactos();

    document.getElementById("btnEnviar").addEventListener("click", enviarMensaje);
    document.getElementById("btnMensajePrivadoSeguro").addEventListener("click", enviarMensajePrivadoSeguro);
    document.getElementById("btnRecibirMensajesSeguro").addEventListener("click", recibirMensajesSeguro);
}

// Verificar si hay mensajes nuevos cada 5 segundos
setInterval(() => {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    if (mensajes[usuario.id] && mensajes[usuario.id].length > 0) {
        efectoNotificacion();
    }
}, 5000);
// Función para agregar un efecto de notificación cuando llega un mensaje
function efectoNotificacion() {
    let tituloOriginal = document.title;
    let nuevoTitulo = "🔔 Nuevo mensaje!";
    let alternar = false;

    let intervalo = setInterval(() => {
        document.title = alternar ? tituloOriginal : nuevoTitulo;
        alternar = !alternar;
    }, 1000);

    setTimeout(() => {
        clearInterval(intervalo);
        document.title = tituloOriginal;
    }, 8000);
}

// Función para reproducir un sonido cuando se recibe un mensaje
function sonidoNotificacion() {
    let audio = new Audio("notificacion.mp3");
    audio.play();
}

// Función para recibir mensajes con notificación y sonido
function recibirMensajesConNotificacion() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};
    let clave = 5; // Clave de desencriptación

    if (mensajes[usuario.id] && mensajes[usuario.id].length > 0) {
        let bandeja = "📩 Mensajes recibidos:\n";
        
        mensajes[usuario.id].forEach((mensaje, index) => {
            let mensajeDesencriptado = desencriptarMensaje(mensaje.contenido, clave);
            bandeja += `${index + 1}. De ${mensaje.de}: ${mensajeDesencriptado} (${mensaje.timestamp})\n`;
        });

        alert(bandeja);
        sonidoNotificacion();
        efectoNotificacion();

        // Limpiar mensajes después de leerlos
        delete mensajes[usuario.id];
        localStorage.setItem("mensajes", JSON.stringify(mensajes));
    } else {
        alert("📭 No tienes mensajes nuevos.");
    }
}

// Función para activar o desactivar las notificaciones
function configurarNotificaciones() {
    let activar = confirm("¿Quieres activar las notificaciones sonoras y visuales?");
    localStorage.setItem("notificaciones", activar);
    alert(`Notificaciones ${activar ? "activadas" : "desactivadas"}.`);
}

// Función para enviar un mensaje normal con efecto visual
function enviarMensajeAnimado() {
    let inputMensaje = document.getElementById("inputMensaje");
    let mensaje = inputMensaje.value.trim();

    if (mensaje === "") {
        alert("Escribe un mensaje antes de enviarlo.");
        return;
    }

    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let chatMensajes = document.getElementById("chatMensajes");

    let mensajeElemento = document.createElement("div");
    mensajeElemento.classList.add("mensaje-enviado");
    mensajeElemento.innerHTML = `<b>${usuario.nombre}:</b> ${mensaje}`;
    
    chatMensajes.appendChild(mensajeElemento);
    inputMensaje.value = "";

    // Animación de aparición
    mensajeElemento.style.opacity = "0";
    setTimeout(() => {
        mensajeElemento.style.opacity = "1";
        mensajeElemento.style.transition = "opacity 0.5s";
    }, 100);
}

// Modificar la interfaz para incluir botones de configuración
function cargarInterfazChatNotificaciones() {
    document.body.innerHTML = `
        <div id="chatContainer">
            <h2>Bienvenido, ${JSON.parse(localStorage.getItem("usuario")).nombre}</h2>
            <div id="chatMensajes"></div>
            <input type="text" id="inputMensaje" placeholder="Escribe un mensaje...">
            <button id="btnEnviar">Enviar</button>
            <button id="btnRecibirMensajesNotif">Ver Mensajes con Notificación</button>
            <button id="btnConfigurarNotificaciones">Configurar Notificaciones</button>
        </div>
    `;

    cargarMenuContactos();

    document.getElementById("btnEnviar").addEventListener("click", enviarMensajeAnimado);
    document.getElementById("btnRecibirMensajesNotif").addEventListener("click", recibirMensajesConNotificacion);
    document.getElementById("btnConfigurarNotificaciones").addEventListener("click", configurarNotificaciones);
}

// Verificar si hay mensajes nuevos cada 5 segundos con notificación opcional
setInterval(() => {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};
    let notificacionesActivadas = JSON.parse(localStorage.getItem("notificaciones"));

    if (mensajes[usuario.id] && mensajes[usuario.id].length > 0 && notificacionesActivadas) {
        efectoNotificacion();
        sonidoNotificacion();
    }
}, 5000);
// Función para eliminar un mensaje específico
function eliminarMensaje() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    if (!mensajes[usuario.id] || mensajes[usuario.id].length === 0) {
        alert("No tienes mensajes para eliminar.");
        return;
    }

    let listaMensajes = mensajes[usuario.id].map((mensaje, index) => {
        return `${index + 1}. De ${mensaje.de}: ${mensaje.contenido} (${mensaje.timestamp})`;
    }).join("\n");

    let indice = prompt(`Selecciona el número del mensaje que quieres eliminar:\n${listaMensajes}`);

    if (indice && !isNaN(indice) && mensajes[usuario.id][indice - 1]) {
        mensajes[usuario.id].splice(indice - 1, 1);
        localStorage.setItem("mensajes", JSON.stringify(mensajes));
        alert("Mensaje eliminado correctamente.");
    } else {
        alert("Selección inválida.");
    }
}

// Función para modificar un mensaje enviado
function modificarMensaje() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    if (!mensajes[usuario.id] || mensajes[usuario.id].length === 0) {
        alert("No tienes mensajes para modificar.");
        return;
    }

    let listaMensajes = mensajes[usuario.id].map((mensaje, index) => {
        return `${index + 1}. De ${mensaje.de}: ${mensaje.contenido} (${mensaje.timestamp})`;
    }).join("\n");

    let indice = prompt(`Selecciona el número del mensaje que quieres modificar:\n${listaMensajes}`);

    if (indice && !isNaN(indice) && mensajes[usuario.id][indice - 1]) {
        let nuevoContenido = prompt("Escribe el nuevo contenido del mensaje:");

        if (nuevoContenido) {
            mensajes[usuario.id][indice - 1].contenido = nuevoContenido;
            mensajes[usuario.id][indice - 1].timestamp = new Date().toLocaleString();
            localStorage.setItem("mensajes", JSON.stringify(mensajes));
            alert("Mensaje modificado correctamente.");
        } else {
            alert("No se hizo ninguna modificación.");
        }
    } else {
        alert("Selección inválida.");
    }
}

// Función para marcar un mensaje como leído
function marcarMensajeComoLeido() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    if (!mensajes[usuario.id] || mensajes[usuario.id].length === 0) {
        alert("No tienes mensajes para marcar como leídos.");
        return;
    }

    let listaMensajes = mensajes[usuario.id].map((mensaje, index) => {
        let leido = mensaje.leido ? "✅" : "❌";
        return `${index + 1}. De ${mensaje.de}: ${mensaje.contenido} (${mensaje.timestamp}) [Leído: ${leido}]`;
    }).join("\n");

    let indice = prompt(`Selecciona el número del mensaje que quieres marcar como leído:\n${listaMensajes}`);

    if (indice && !isNaN(indice) && mensajes[usuario.id][indice - 1]) {
        mensajes[usuario.id][indice - 1].leido = true;
        localStorage.setItem("mensajes", JSON.stringify(mensajes));
        alert("Mensaje marcado como leído.");
    } else {
        alert("Selección inválida.");
    }
}

// Función para mostrar la interfaz con las opciones nuevas
function cargarInterfazChatOpciones() {
    document.body.innerHTML = `
        <div id="chatContainer">
            <h2>Bienvenido, ${JSON.parse(localStorage.getItem("usuario")).nombre}</h2>
            <div id="chatMensajes"></div>
            <input type="text" id="inputMensaje" placeholder="Escribe un mensaje...">
            <button id="btnEnviar">Enviar</button>
            <button id="btnRecibirMensajesNotif">Ver Mensajes</button>
            <button id="btnConfigurarNotificaciones">Configurar Notificaciones</button>
            <button id="btnEliminarMensaje">Eliminar Mensaje</button>
            <button id="btnModificarMensaje">Modificar Mensaje</button>
            <button id="btnMarcarLeido">Marcar como Leído</button>
        </div>
    `;

    cargarMenuContactos();

    document.getElementById("btnEnviar").addEventListener("click", enviarMensajeAnimado);
    document.getElementById("btnRecibirMensajesNotif").addEventListener("click", recibirMensajesConNotificacion);
    document.getElementById("btnConfigurarNotificaciones").addEventListener("click", configurarNotificaciones);
    document.getElementById("btnEliminarMensaje").addEventListener("click", eliminarMensaje);
    document.getElementById("btnModificarMensaje").addEventListener("click", modificarMensaje);
    document.getElementById("btnMarcarLeido").addEventListener("click", marcarMensajeComoLeido);
}
// Función para animar el envío de un mensaje con efecto de fade-in
function enviarMensajeAnimado() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};
    let destinatario = prompt("Ingresa la ID del usuario a quien deseas enviar el mensaje:");

    if (!destinatario) {
        alert("Debes ingresar un destinatario.");
        return;
    }

    let contenido = document.getElementById("inputMensaje").value.trim();
    if (!contenido) {
        alert("No puedes enviar un mensaje vacío.");
        return;
    }

    let mensaje = {
        de: usuario.nombre,
        contenido: contenido,
        timestamp: new Date().toLocaleString(),
        leido: false
    };

    if (!mensajes[destinatario]) {
        mensajes[destinatario] = [];
    }

    mensajes[destinatario].push(mensaje);
    localStorage.setItem("mensajes", JSON.stringify(mensajes));

    let chatMensajes = document.getElementById("chatMensajes");
    let nuevoMensaje = document.createElement("div");
    nuevoMensaje.classList.add("mensaje", "fade-in");
    nuevoMensaje.innerHTML = `<strong>Tú:</strong> ${contenido} <span class="timestamp">(${mensaje.timestamp})</span>`;
    chatMensajes.appendChild(nuevoMensaje);

    document.getElementById("inputMensaje").value = "";
}

// Función para recibir mensajes con animación de desvanecimiento
function recibirMensajesConAnimacion() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    if (!mensajes[usuario.id] || mensajes[usuario.id].length === 0) {
        alert("No tienes mensajes nuevos.");
        return;
    }

    let chatMensajes = document.getElementById("chatMensajes");
    chatMensajes.innerHTML = "";

    mensajes[usuario.id].forEach(mensaje => {
        let mensajeDiv = document.createElement("div");
        mensajeDiv.classList.add("mensaje", "fade-in");
        mensajeDiv.innerHTML = `<strong>${mensaje.de}:</strong> ${mensaje.contenido} <span class="timestamp">(${mensaje.timestamp})</span>`;
        chatMensajes.appendChild(mensajeDiv);
    });

    // Aplicar animación de "leído" a los mensajes después de 2 segundos
    setTimeout(() => {
        document.querySelectorAll(".mensaje").forEach(msg => {
            msg.classList.add("leido");
        });
    }, 2000);
}

// Función para notificar mensajes con sonido y animación en la pestaña
function recibirMensajesConNotificacion() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    if (!mensajes[usuario.id] || mensajes[usuario.id].length === 0) {
        alert("No tienes mensajes nuevos.");
        return;
    }

    let chatMensajes = document.getElementById("chatMensajes");
    chatMensajes.innerHTML = "";

    mensajes[usuario.id].forEach(mensaje => {
        let mensajeDiv = document.createElement("div");
        mensajeDiv.classList.add("mensaje", "fade-in");
        mensajeDiv.innerHTML = `<strong>${mensaje.de}:</strong> ${mensaje.contenido} <span class="timestamp">(${mensaje.timestamp})</span>`;
        chatMensajes.appendChild(mensajeDiv);
    });

    let sonido = new Audio("notificacion.mp3");
    sonido.play();

    let tituloOriginal = document.title;
    document.title = "📩 ¡Tienes un nuevo mensaje!";
    
    setTimeout(() => {
        document.title = tituloOriginal;
    }, 3000);
}

// Agregar un botón flotante para cambiar el tema de la app
function agregarBotonTema() {
    let botonTema = document.createElement("button");
    botonTema.id = "botonTema";
    botonTema.textContent = "🌙 Modo Oscuro";
    document.body.appendChild(botonTema);

    botonTema.addEventListener("click", () => {
        document.body.classList.toggle("modo-oscuro");
        if (document.body.classList.contains("modo-oscuro")) {
            botonTema.textContent = "☀️ Modo Claro";
        } else {
            botonTema.textContent = "🌙 Modo Oscuro";
        }
    });
}

// Cargar la interfaz con efectos visuales y opciones nuevas
function cargarInterfazChatConEfectos() {
    document.body.innerHTML = `
        <div id="chatContainer">
            <h2>Bienvenido, ${JSON.parse(localStorage.getItem("usuario")).nombre}</h2>
            <div id="chatMensajes"></div>
            <input type="text" id="inputMensaje" placeholder="Escribe un mensaje...">
            <button id="btnEnviar">Enviar</button>
            <button id="btnRecibirMensajes">Ver Mensajes</button>
            <button id="btnNotificar">Notificaciones</button>
            <button id="btnTema">Modo Oscuro</button>
        </div>
    `;

    agregarBotonTema();

    document.getElementById("btnEnviar").addEventListener("click", enviarMensajeAnimado);
    document.getElementById("btnRecibirMensajes").addEventListener("click", recibirMensajesConAnimacion);
    document.getElementById("btnNotificar").addEventListener("click", recibirMensajesConNotificacion);
}
// Función para buscar mensajes dentro del chat
function buscarMensajes() {
    let terminoBusqueda = prompt("Ingresa una palabra clave para buscar en los mensajes:");
    if (!terminoBusqueda) {
        alert("Debes ingresar un término de búsqueda.");
        return;
    }

    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};
    let chatMensajes = document.getElementById("chatMensajes");

    chatMensajes.innerHTML = "";

    if (mensajes[usuario.id]) {
        let encontrados = mensajes[usuario.id].filter(m => m.contenido.includes(terminoBusqueda));
        
        if (encontrados.length === 0) {
            chatMensajes.innerHTML = "<p>No se encontraron mensajes con esa palabra.</p>";
        } else {
            encontrados.forEach(mensaje => {
                let mensajeDiv = document.createElement("div");
                mensajeDiv.classList.add("mensaje");
                mensajeDiv.innerHTML = `<strong>${mensaje.de}:</strong> ${mensaje.contenido} <span class="timestamp">(${mensaje.timestamp})</span>`;
                chatMensajes.appendChild(mensajeDiv);
            });
        }
    } else {
        chatMensajes.innerHTML = "<p>No tienes mensajes.</p>";
    }
}

// Función para eliminar todos los mensajes de una conversación
function eliminarConversacion() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};
    
    let confirmacion = confirm("¿Estás seguro de que deseas eliminar todos los mensajes?");
    if (!confirmacion) return;

    if (mensajes[usuario.id]) {
        delete mensajes[usuario.id];
        localStorage.setItem("mensajes", JSON.stringify(mensajes));
        document.getElementById("chatMensajes").innerHTML = "<p>Conversación eliminada.</p>";
        alert("Todos los mensajes han sido eliminados.");
    } else {
        alert("No tienes mensajes para eliminar.");
    }
}

// Función para marcar mensajes como leídos
function confirmarLecturaMensajes() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    if (mensajes[usuario.id]) {
        mensajes[usuario.id].forEach(m => m.leido = true);
        localStorage.setItem("mensajes", JSON.stringify(mensajes));
        alert("Todos los mensajes han sido marcados como leídos.");
    } else {
        alert("No tienes mensajes nuevos.");
    }
}

// Agregar un botón de exportación de mensajes
function exportarMensajes() {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    if (!mensajes[usuario.id] || mensajes[usuario.id].length === 0) {
        alert("No tienes mensajes para exportar.");
        return;
    }

    let contenido = "Mensajes de " + usuario.nombre + ":\n";
    mensajes[usuario.id].forEach(m => {
        contenido += `${m.timestamp} - ${m.de}: ${m.contenido}\n`;
    });

    let blob = new Blob([contenido], { type: "text/plain" });
    let enlace = document.createElement("a");
    enlace.href = URL.createObjectURL(blob);
    enlace.download = "chat_exportado.txt";
    enlace.click();
}

// Función para mostrar la lista de usuarios guardados
function mostrarUsuariosGuardados() {
    let usuarios = JSON.parse(localStorage.getItem("usuariosGuardados")) || [];
    let lista = "Usuarios guardados:\n";
    if (usuarios.length === 0) {
        lista += "No tienes usuarios guardados.";
    } else {
        usuarios.forEach(u => {
            lista += `${u.nombre} - ID: ${u.id}\n`;
        });
    }
    alert(lista);
}

// Agregar botones para las nuevas funciones
function agregarBotonesExtras() {
    let botonesContainer = document.createElement("div");
    botonesContainer.id = "botonesExtras";
    
    let btnBuscar = document.createElement("button");
    btnBuscar.textContent = "🔍 Buscar Mensajes";
    btnBuscar.addEventListener("click", buscarMensajes);

    let btnEliminar = document.createElement("button");
    btnEliminar.textContent = "🗑️ Eliminar Conversación";
    btnEliminar.addEventListener("click", eliminarConversacion);

    let btnConfirmarLectura = document.createElement("button");
    btnConfirmarLectura.textContent = "✅ Confirmar Lectura";
    btnConfirmarLectura.addEventListener("click", confirmarLecturaMensajes);

    let btnExportar = document.createElement("button");
    btnExportar.textContent = "📁 Exportar Chat";
    btnExportar.addEventListener("click", exportarMensajes);

    let btnUsuarios = document.createElement("button");
    btnUsuarios.textContent = "👥 Ver Usuarios Guardados";
    btnUsuarios.addEventListener("click", mostrarUsuariosGuardados);

    botonesContainer.appendChild(btnBuscar);
    botonesContainer.appendChild(btnEliminar);
    botonesContainer.appendChild(btnConfirmarLectura);
    botonesContainer.appendChild(btnExportar);
    botonesContainer.appendChild(btnUsuarios);

    document.body.appendChild(botonesContainer);
}

// Cargar la interfaz con todas las funciones avanzadas
function cargarInterfazAvanzada() {
    document.body.innerHTML = `
        <div id="chatContainer">
            <h2>Bienvenido, ${JSON.parse(localStorage.getItem("usuario")).nombre}</h2>
            <div id="chatMensajes"></div>
            <input type="text" id="inputMensaje" placeholder="Escribe un mensaje...">
            <button id="btnEnviar">Enviar</button>
            <button id="btnRecibirMensajes">Ver Mensajes</button>
            <button id="btnNotificar">Notificaciones</button>
            <button id="btnTema">Modo Oscuro</button>
        </div>
    `;

    agregarBotonesExtras();

    document.getElementById("btnEnviar").addEventListener("click", enviarMensajeAnimado);
    document.getElementById("btnRecibirMensajes").addEventListener("click", recibirMensajesConAnimacion);
    document.getElementById("btnNotificar").addEventListener("click", recibirMensajesConNotificacion);
}
// Función para agregar emojis a los mensajes
function agregarEmojis() {
    let emojis = ["😀", "😂", "❤️", "👍", "🔥", "😎", "🤔", "😭", "🎉", "💡"];
    let emojiContainer = document.createElement("div");
    emojiContainer.id = "emojiContainer";

    emojis.forEach(emoji => {
        let boton = document.createElement("button");
        boton.classList.add("emoji-btn");
        boton.textContent = emoji;
        boton.addEventListener("click", () => {
            let input = document.getElementById("inputMensaje");
            input.value += emoji;
        });
        emojiContainer.appendChild(boton);
    });

    document.body.appendChild(emojiContainer);
}

// Función para mostrar el estado en línea/desconectado
function actualizarEstadoUsuario(estado) {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    usuario.estado = estado;
    localStorage.setItem("usuario", JSON.stringify(usuario));

    let estadoElemento = document.getElementById("estadoUsuario");
    if (!estadoElemento) {
        estadoElemento = document.createElement("p");
        estadoElemento.id = "estadoUsuario";
        document.body.appendChild(estadoElemento);
    }
    estadoElemento.textContent = `Estado: ${estado === "online" ? "🟢 En línea" : "🔴 Desconectado"}`;
}

// Función para que los mensajes se autodestruyan después de un tiempo
function activarAutodestruccion(mensajeID, tiempo) {
    setTimeout(() => {
        let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};
        let usuario = JSON.parse(localStorage.getItem("usuario"));

        if (mensajes[usuario.id]) {
            mensajes[usuario.id] = mensajes[usuario.id].filter(m => m.id !== mensajeID);
            localStorage.setItem("mensajes", JSON.stringify(mensajes));
            document.getElementById(`msg-${mensajeID}`)?.remove();
            console.log(`Mensaje ${mensajeID} eliminado automáticamente.`);
        }
    }, tiempo * 1000);
}

// Función para abrir múltiples chats activos
function abrirChatCon(usuarioID) {
    let usuario = JSON.parse(localStorage.getItem("usuario"));
    if (!usuario) {
        alert("Primero debes registrarte.");
        return;
    }

    let chatWindow = document.createElement("div");
    chatWindow.classList.add("chatWindow");
    chatWindow.innerHTML = `
        <h3>Chat con ${usuarioID}</h3>
        <div class="chatMensajes" id="mensajes-${usuarioID}"></div>
        <input type="text" id="input-${usuarioID}" placeholder="Escribe un mensaje...">
        <button onclick="enviarMensajeA('${usuarioID}')">Enviar</button>
    `;
    document.body.appendChild(chatWindow);

    cargarMensajesDe(usuarioID);
}

// Función para enviar mensajes en múltiples chats
function enviarMensajeA(destinoID) {
    let input = document.getElementById(`input-${destinoID}`);
    let mensaje = input.value.trim();
    if (!mensaje) return;

    let usuario = JSON.parse(localStorage.getItem("usuario"));
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};

    let nuevoMensaje = {
        id: Date.now(),
        de: usuario.nombre,
        contenido: mensaje,
        timestamp: new Date().toLocaleTimeString(),
    };

    if (!mensajes[destinoID]) mensajes[destinoID] = [];
    mensajes[destinoID].push(nuevoMensaje);
    localStorage.setItem("mensajes", JSON.stringify(mensajes));

    let chatMensajes = document.getElementById(`mensajes-${destinoID}`);
    let mensajeDiv = document.createElement("div");
    mensajeDiv.classList.add("mensaje");
    mensajeDiv.innerHTML = `<strong>${usuario.nombre}:</strong> ${mensaje} <span class="timestamp">(${nuevoMensaje.timestamp})</span>`;
    chatMensajes.appendChild(mensajeDiv);

    input.value = "";
    activarAutodestruccion(nuevoMensaje.id, 60); // Mensajes desaparecen después de 60 segundos
}

// Función para cargar mensajes de un usuario específico
function cargarMensajesDe(usuarioID) {
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || {};
    let chatMensajes = document.getElementById(`mensajes-${usuarioID}`);

    if (!mensajes[usuarioID] || mensajes[usuarioID].length === 0) {
        chatMensajes.innerHTML = "<p>No hay mensajes.</p>";
    } else {
        chatMensajes.innerHTML = "";
        mensajes[usuarioID].forEach(m => {
            let mensajeDiv = document.createElement("div");
            mensajeDiv.classList.add("mensaje");
            mensajeDiv.id = `msg-${m.id}`;
            mensajeDiv.innerHTML = `<strong>${m.de}:</strong> ${m.contenido} <span class="timestamp">(${m.timestamp})</span>`;
            chatMensajes.appendChild(mensajeDiv);
        });
    }
}

// Función para cerrar sesión
function cerrarSesion() {
    localStorage.removeItem("usuario");
    location.reload();
}

// Cargar la interfaz mejorada con nuevas funciones
function cargarInterfazMejorada() {
    document.body.innerHTML = `
        <div id="chatContainer">
            <h2>Bienvenido, ${JSON.parse(localStorage.getItem("usuario")).nombre}</h2>
            <p id="estadoUsuario"></p>
            <button onclick="actualizarEstadoUsuario('online')">🟢 Conectado</button>
            <button onclick="actualizarEstadoUsuario('offline')">🔴 Desconectado</button>
            <button onclick="cerrarSesion()">🚪 Cerrar Sesión</button>
            <div id="chatMensajes"></div>
            <input type="text" id="inputMensaje" placeholder="Escribe un mensaje...">
            <button id="btnEnviar">Enviar</button>
            <button id="btnRecibirMensajes">Ver Mensajes</button>
            <button id="btnNotificar">Notificaciones</button>
            <button id="btnTema">Modo Oscuro</button>
            <button onclick="agregarEmojis()">😊 Emojis</button>
            <button onclick="abrirChatCon(prompt('Ingresa el ID del usuario con el que deseas chatear:'))">📩 Nuevo Chat</button>
        </div>
    `;

    agregarEmojis();
    actualizarEstadoUsuario("online");

    document.getElementById("btnEnviar").addEventListener("click", enviarMensajeAnimado);
    document.getElementById("btnRecibirMensajes").addEventListener("click", recibirMensajesConAnimacion);
    document.getElementById("btnNotificar").addEventListener("click", recibirMensajesConNotificacion);
}
// Función para activar el modo oscuro
function activarModoOscuro() {
    let body = document.body;
    body.classList.toggle("modo-oscuro");

    let estadoModo = body.classList.contains("modo-oscuro") ? "on" : "off";
    localStorage.setItem("modoOscuro", estadoModo);
}

// Función para mostrar notificaciones cuando llega un mensaje nuevo
function recibirMensajesConNotificacion() {
    if (!("Notification" in window)) {
        alert("Tu navegador no soporta notificaciones.");
        return;
    }

    if (Notification.permission === "granted") {
        mostrarNotificacion("¡Nuevo mensaje!", "Tienes un nuevo mensaje en el chat.");
    } else if (Notification.permission !== "denied") {
        Notification.requestPermission().then((permiso) => {
            if (permiso === "granted") {
                mostrarNotificacion("¡Nuevo mensaje!", "Tienes un nuevo mensaje en el chat.");
            }
        });
    }
}

// Función para mostrar una notificación personalizada
function mostrarNotificacion(titulo, mensaje) {
    let opciones = {
        body: mensaje,
        icon: "icono-chat.png",
    };
    let notificacion = new Notification(titulo, opciones);

    // Opcional: Redirigir al usuario al chat cuando haga clic en la notificación
    notificacion.onclick = function () {
        window.focus();
    };
}

// Función para animar el envío de mensajes
function enviarMensajeAnimado() {
    let input = document.getElementById("inputMensaje");
    let mensaje = input.value.trim();
    if (!mensaje) return;

    let chatMensajes = document.getElementById("chatMensajes");
    let mensajeDiv = document.createElement("div");
    mensajeDiv.classList.add("mensaje", "animarMensaje");
    mensajeDiv.innerHTML = `<strong>Tú:</strong> ${mensaje}`;
    chatMensajes.appendChild(mensajeDiv);

    reproducirSonido("enviar.mp3");
    input.value = "";
}

// Función para recibir mensajes con animación
function recibirMensajesConAnimacion() {
    let mensajes = JSON.parse(localStorage.getItem("mensajes")) || [];
    let chatMensajes = document.getElementById("chatMensajes");

    mensajes.forEach(m => {
        let mensajeDiv = document.createElement("div");
        mensajeDiv.classList.add("mensaje", "animarMensaje");
        mensajeDiv.innerHTML = `<strong>${m.de}:</strong> ${m.contenido}`;
        chatMensajes.appendChild(mensajeDiv);
    });

    reproducirSonido("recibir.mp3");
}

// Función para reproducir efectos de sonido
function reproducirSonido(archivo) {
    let audio = new Audio(archivo);
    audio.play();
}

// Aplicar configuración guardada del modo oscuro
document.addEventListener("DOMContentLoaded", () => {
    let estadoModo = localStorage.getItem("modoOscuro");
    if (estadoModo === "on") {
        document.body.classList.add("modo-oscuro");
    }
});

// Agregar botón para activar el modo oscuro
document.getElementById("btnTema").addEventListener("click", activarModoOscuro);
